package Model;

import java.util.ArrayList;

public class File {
    private String fileName;
    private static ArrayList<File> allFiles = new ArrayList<>();
    private Directory parent;
    private String fileFormat;
    private String path;
    private boolean isHeaden;
    private User whoShared;
    private User whoISharedToIt;
    private Text text;
    private Text originalText;
    private boolean isZip;
    private int round;

    public File(String fileName, Directory parent, String fileFormat, boolean isHeaden, boolean isZip, String path) {
        this.fileName = fileName;
        this.fileFormat = fileFormat;
        this.isHeaden = isHeaden;
        this.parent = parent;
        allFiles.add(this);
        this.isZip = isZip;
        this.path = path;
        this.text = new Text();
    }

    public Text getText() {
        return this.text;
    }

    public void setText(Text text) {
        this.text = text;
    }

    public void setOriginalText(Text text) {
        this.originalText = originalText;
    }

    public boolean getIsHeaden() {
        return this.isHeaden;
    }

    public Text getOriginalText() {
        return this.originalText;
    }

    public static void setAllFiles(File file) {
        allFiles.add(file);
    }

    public User getWhoShared() {
        return this.whoShared;
    }

    public String getFileFormat() {
        return this.fileFormat;
    }

    public boolean getIsZip() {
        return this.isZip;
    }

    public void setParent(Directory directory) {
        this.parent = directory;
    }

    public void setIsZip(boolean isZip) {
        this.isZip = isZip;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getRound() {
        return this.round;
    }

    public static void removeFromAllFiles(File file) {
        allFiles.remove(file);
    }

    public String getFileName() {
        return this.fileName;
    }

    public Directory getParent() {
        return this.parent;
    }

    public void setWhoShared(User users) {
        this.whoShared = users;
    }

    public void setWhoISharedToIt(User users) {
        this.whoISharedToIt = users;
    }

    public String getPath() {
        return this.path;
    }

    public static File getFileByPath(String path) {
        for (int q = 0; q < allFiles.size(); q++) {
            if (allFiles.get(q).getPath().equals(path)) {
                return allFiles.get(q);
            }
        }
        return null;
    }

    public void setIsHeaden(boolean isHeaden) {
        this.isHeaden = isHeaden;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public static ArrayList getAllFiles() {
        return allFiles;
    }
}
