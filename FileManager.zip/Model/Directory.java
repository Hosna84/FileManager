package Model;

import java.util.ArrayList;

public class Directory {
    private Directory parent;
    private String path;
    private ArrayList<Directory> dirChildren = new ArrayList<>();
    private ArrayList<File> fileChildren = new ArrayList<>();
    private boolean isHeaden;
    private User whoShared;
    private User whoIShareToIt;
    private String dirName;
    private static ArrayList<Directory> allDirectories = new ArrayList<>();
    private static Directory currentDirectory;
    private int round;

    public Directory(String dirName, String path, Directory parnet, boolean isHeaden) {
        this.dirName = dirName;
        this.parent = parnet;
        this.isHeaden = isHeaden;
        allDirectories.add(this);
        this.path = path;

    }

    public static void addToAllDirs(Directory directory) {
        allDirectories.add(directory);
    }

    public void setRound(int round) {
        this.round = round;
    }

    public int getRound() {
        return this.round;
    }

    public void removeFileFromChildrenFiles(File file) {

        this.fileChildren.remove(file);
    }

    public Directory getParent() {
        return this.parent;
    }

    public void setParent(Directory directory) {
        this.parent = directory;
    }

    public void addToChildrenOfADir(Directory maghsad, Directory directory) {
        if (maghsad != null)
            maghsad.getDirChildren().add(directory);
    }

    public void addToChildrenOfADir(Directory maghsad, File file) {
        if (maghsad != null)
            maghsad.getFileChildren().add(file);
    }

    public static Directory getCurrentDirectory() {
        return currentDirectory;
    }

    public static ArrayList getAllDirectories() {
        return allDirectories;
    }

    public static void setCurrentDirectory(Directory directory) {
        currentDirectory = directory;
    }

    public ArrayList<Directory> getDirChildren() {
        return this.dirChildren;
    }

    public static void removeFromDirs(Directory directory) {
        allDirectories.remove(directory);
    }

    public ArrayList<File> getFileChildren() {
        return this.fileChildren;
    }

    public void removeDirFromChildren(Directory directory) {
        dirChildren.remove(directory);
    }

    public String getDirName() {
        return this.dirName;
    }

    public String getPath() {
        return this.path;
    }

    public void setWhoShared(User users) {
        this.whoShared = users;
    }

    public void setWhoIShareToIt(User users) {
        this.whoIShareToIt = users;
    }

    public User getWhoShared() {
        return this.whoShared;
    }

    public static Directory getDirByPath(String path) {
        for (int q = 0; q < allDirectories.size(); q++) {
            if (allDirectories.get(q).getPath().equals(path)) {
                return allDirectories.get(q);
            }
        }
        return null;
    }

    public void setIsHeaden(boolean isHeaden) {
        this.isHeaden = isHeaden;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setDirName(String dirName) {
        this.dirName = dirName;
    }

}
