package Model;

import java.util.ArrayList;

public class Zip extends File {
    private ArrayList<File> filesInZip = new ArrayList<>();
    private ArrayList<Directory> directoriesInZip = new ArrayList<>();
    private static ArrayList<Zip> allZips = new ArrayList<>();

    public Zip(String fileName, Directory parent, String fileFormat,
               boolean isHeaden, boolean isZip,
               String path, ArrayList<File> selecredFiles, ArrayList<Directory> selectedDirs) {
        super(fileName, parent, fileFormat, isHeaden, isZip, path);
        filesInZip = selecredFiles;
        directoriesInZip = selectedDirs;
        allZips.add(this);
        User.getLoggedInUser().addFileToWhatIHave(this);
    }

    public ArrayList<File> getFilesInZip() {
        return this.filesInZip;
    }

    public ArrayList<Directory> getDirsInZip() {
        return this.directoriesInZip;
    }

    public static ArrayList getAllZips() {
        return allZips;
    }
}
