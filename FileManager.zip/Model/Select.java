package Model;

import Model.Directory;
import Model.File;

import java.util.ArrayList;

public class Select {
    private ArrayList<File> selectedFiles = new ArrayList<>();
    private ArrayList<Directory> selectedDirs = new ArrayList<>();

    public void addToFiles(File file) {
        selectedFiles.add(file);
        file.setRound(2);
    }

    public void addToDirs(Directory directory) {
        selectedDirs.add(directory);
        directory.setRound(2);
    }

    public void reduceRound() {
        for (int i = 0; i < this.selectedFiles.size(); i++) {
            if (selectedFiles.get(i) != null) {
                if (selectedFiles.get(i).getRound() == 0) {
                    selectedFiles.remove(i);
                } else if (selectedFiles.get(i).getRound() > 0) {
                    selectedFiles.get(i).setRound(selectedFiles.get(i).getRound() - 1);
                }
            }
        }
        for (int i = 0; i < this.selectedDirs.size(); i++) {
            if (selectedDirs.get(i) != null) {
                if (selectedDirs.get(i).getRound() == 0) {
                    selectedDirs.remove(i);
                } else if (selectedDirs.get(i).getRound() > 0) {
                    selectedDirs.get(i).setRound(selectedDirs.get(i).getRound() - 1);
                }
            }
        }
    }

    public void changeSelectedDirs(ArrayList<Directory> directories) {
        this.selectedDirs = directories;
        for (int i = 0; i < selectedDirs.size(); i++) {
            selectedDirs.get(i).setRound(2);
        }
    }

    public void changeSelectedFiles(ArrayList<File> files) {
        this.selectedFiles = files;
        for (int i = 0; i < selectedFiles.size(); i++) {
            selectedFiles.get(i).setRound(2);
        }
    }

    public void removeFromSelectedFiles(File file) {
        selectedFiles.remove(file);
    }

    public void removwFromSelectedDirs(Directory directory) {
        selectedDirs.remove(directory);
    }


    public ArrayList<File> getSelctedFiles() {
        return this.selectedFiles;
    }

    public ArrayList<Directory> getSelectedDirs() {
        return this.selectedDirs;
    }
}
