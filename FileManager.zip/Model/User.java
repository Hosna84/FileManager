package Model;

import java.util.ArrayList;

public class User {
    private String username;
    private String password;
    private boolean isOneTime;
    private static User loggedinUser;
    private static ArrayList<User> allUsers = new ArrayList<>();
    private ArrayList<User> whoIBlocked = new ArrayList<>();
    private ArrayList<User> whoBlockedMe = new ArrayList<>();
    private ArrayList<File> whatFilesISharedToOthers = new ArrayList<>();
    private ArrayList<File> whatFilesIsSharedToMe = new ArrayList<>();
    private ArrayList<Directory> whatDirISharedToOthers = new ArrayList<>();
    private ArrayList<Directory> whatDirIsSharedToMe = new ArrayList<>();
    private ArrayList<File> whatFileIHave = new ArrayList<>();
    private ArrayList<Directory> whatDirIHave = new ArrayList<>();
    private Directory root;

    public User(String username, String password, boolean isOneTime, Directory root) {
        this.username = username;
        this.password = password;
        this.isOneTime = isOneTime;
        allUsers.add(this);
        this.root = root;
    }

    public String getUsername() {
        return this.username;
    }

    public boolean getIsOneTime() {
        return this.isOneTime;
    }

    public static ArrayList getUsers() {
        return allUsers;
    }

    public String getPassword() {
        return this.password;
    }

    public static User getLoggedInUser() {
        return loggedinUser;
    }

    public static User getUsersByUsername(String username) {
        for (int q = 0; q < allUsers.size(); q++) {
            if (allUsers.get(q).getUsername().equals(username)) {
                return allUsers.get(q);
            }
        }
        return null;
    }

    public static void setLoggedinUser(User user) {
        loggedinUser = user;
    }

    public ArrayList<User> getWhoIBlocked() {
        return this.whoIBlocked;
    }

    public ArrayList<User> getWhoBlockedMe() {
        return this.whoBlockedMe;
    }

    public void setWhoIBlocked(User users) {
        this.whoIBlocked.add(users);
    }

    public void setWhoBlockedMe(User users) {
        this.whoBlockedMe.add(users);
    }

    public void removeWhoBlockedMe(User users) {
        this.whoBlockedMe.remove(users);
    }

    public void removeWhoIBlocked(User users) {
        this.whoIBlocked.remove(users);
    }

    public static void removeFromUsersForOneTime(User user) {
        allUsers.remove(user);
    }

    public void addDirSharedToMe(Directory directory) {
        whatDirIsSharedToMe.add(directory);
    }

    public void addDirWhatIShareToOther(Directory directory) {
        whatDirISharedToOthers.add(directory);
    }

    public void addFileWhatIShareToOther(File file) {
        whatFilesISharedToOthers.add(file);
    }

    public void addFileSharedToMe(File file) {
        whatFilesIsSharedToMe.add(file);
    }

    public Directory getDirByPath(String path) {
        for (int i = 0; i < this.whatDirIHave.size(); i++) {
            if (this.whatDirIHave.get(i).getPath().equals(path))
                return this.whatDirIHave.get(i);
        }
        return null;
    }

    public File getFileByPath(String path) {
        for (int i = 0; i < this.whatFileIHave.size(); i++) {
            if (this.whatFileIHave.get(i).getPath().equals(path))
                return this.whatFileIHave.get(i);
        }
        return null;
    }

    public ArrayList<Directory> getWhatDirIsSharedToMe() {
        return this.whatDirIsSharedToMe;
    }

    public ArrayList<File> getWhatFilesIsSharedToMe() {
        return this.whatFilesIsSharedToMe;
    }

    public ArrayList<File> getWhatFileIHavesIHave() {
        return this.whatFileIHave;
    }

    public void addFileToWhatIHave(File file) {
        this.whatFileIHave.add(file);
    }

    public void addDirToWhatIHave(Directory directory) {
        this.whatDirIHave.add(directory);
    }

    public ArrayList<Directory> getWhatDirIHave() {
        return this.whatDirIHave;
    }

    public void setWhatDirIHave(Directory directory) {
        this.whatDirIHave.add(directory);
    }

    public Directory getRoot() {
        return this.root;
    }

    public void removeFromFilesIHave(File file) {
        this.whatFileIHave.remove(file);
    }

    public void removeFromDirsIHave(Directory directory) {
        this.whatDirIHave.remove(directory);
    }
}
