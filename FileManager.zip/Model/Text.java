package Model;

import java.util.ArrayList;

public class Text {
    private String text;
    private String copied;
    private String cut;
    private int curserIndex;
    private int selectedUntilThisLineNum;
    private int selectedUntilThisPosition;

    public void Text() {
        this.curserIndex = 0;
        this.selectedUntilThisPosition = 0;
        this.selectedUntilThisLineNum = 0;
    }

    public String getCopied() {
        return this.copied;
    }

    public String getCut() {
        return this.cut;
    }

    public void setCopied(String copied) {
        this.copied = copied;
    }

    public void setCut(String cut) {
        this.cut = cut;
    }

    public void setCurserForFirst() {
        this.curserIndex = 0;
        this.selectedUntilThisPosition = 0;
        this.selectedUntilThisLineNum = 0;
    }

    public void takeOutOfSelect() {
        this.selectedUntilThisLineNum = 0;
        this.selectedUntilThisPosition = 0;
    }

    public int getSelectedUntilThisPosition() {
        return this.selectedUntilThisPosition;
    }

    public int getSelectedUntilThisLineNum() {
        return this.selectedUntilThisLineNum;
    }

    public void setSelectedThings(int selectedUntilThisLineNum, int selectedUntilThisPosition) {
        this.selectedUntilThisLineNum = selectedUntilThisLineNum;
        this.selectedUntilThisPosition = selectedUntilThisPosition;
    }

    public String getText() {
        return this.text;
    }


    public int getCurserIndex() {
        return this.curserIndex;
    }

    public void setCurserIndex(int curserIndex) {
        this.curserIndex = curserIndex;
    }

    public void setText(String text) {
        this.text = text;
    }


}
