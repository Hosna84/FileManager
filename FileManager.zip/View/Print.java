package View;

public class Print {
    public static void printingString(String readyToPrint) {
        System.out.println(readyToPrint);
    }

    public static void printingStringBuilder(StringBuilder result) {
        System.out.print(result);
    }
}
