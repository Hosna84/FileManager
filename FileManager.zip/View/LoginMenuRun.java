package View;

import Model.Directory;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static Controller.LoginMenu.creatingUser;
import static Controller.LoginMenu.loginUser;
import static java.lang.System.exit;

public class LoginMenuRun {
    public static void run(Scanner scanner) {
        while (true) {
            String input = scanner.nextLine().trim();
            if (input.matches("create_user -username (?<username>.*) -password (?<password>[^-]*)") && !input.contains("-one_time")) {
                String regex = "create_user -username (?<username>.*) -password (?<password>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                creatingUser(matcher, input);
            } else if (input.matches("create_user -username (?<username>.*) -password (?<password>[^-]*) -one_time")) {
                String regex = "create_user -username (?<username>.*) -password (?<password>[^-]*) -one_time";
                Matcher matcher = getCommandMatcher(input, regex);
                creatingUser(matcher, input);
            } else if (input.matches("login -username (?<username>.*) -password (?<password>.*)")) {
                String regex = "login -username (?<username>.*) -password (?<password>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                boolean goToUserMenu = loginUser(matcher);
                if (goToUserMenu) {
                    Directory.setCurrentDirectory(User.getLoggedInUser().getRoot());
                    UserMenuRun.run(scanner);
                } else continue;
            } else if (input.equals("logout")) {
                System.out.println("There's no account to be logged out");

            } else if (input.equals("exit")) {
                System.exit(0);
            } else System.out.println("invalid command");
        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }
}
