package View;

import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static Controller.UserManu.*;
import static View.Print.printingString;
import static java.lang.System.exit;

public class UserMenuRun {
    public static void run(Scanner scanner) {
        while (true) {
            String input = scanner.nextLine().trim();
            if (input.matches("share -dir (?<dirname>.*) -target (?<username>.*)")) {
                String regex = "share -dir (?<dirname>.*) -target (?<username>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                shareDir(matcher);
            } else if (input.matches("share -file (?<filename>.*) -target (?<username>.*)")) {
                String regex = "share -file (?<filename>.*) -target (?<username>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                shareFile(matcher);

            } else if (input.matches("view -shared -username (?<username>.*)") && !input.contains("-me")
                    && !input.endsWith("-user")) {
                String regex = "view -shared -username (?<username>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                viewSharedThings(matcher);
            } else if (input.matches("view -shared -username (?<username>.*) -me")) {
                String regex = "view -shared -username (?<username>.*) -me";
                Matcher matcher = getCommandMatcher(input, regex);
                viewWithFlagMe(matcher);
            } else if (input.matches("view -shared -username (?<username>.*) -user")) {
                String regex = "view -shared -username (?<username>.*) -user";
                Matcher matcher = getCommandMatcher(input, regex);
                viewWithFlagUser(matcher);
            } else if (input.matches("share_all -dir (?<dirname>.*)")) {
                String regex = "share_all -dir (?<dirname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                shareDirWithAll(matcher);
            } else if (input.matches("share_all -file (?<filename>.*)")) {
                String regex = "share_all -file (?<filename>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                shareFileWithAll(matcher);
            } else if (input.matches("block -user (?<username>.*)")) {
                String regex = "block -user (?<username>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                blockUser(matcher);
            } else if (input.matches("unblock -user (?<username>.\\S*)")) {
                String regex = "unblock -user (?<username>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                unblockUser(matcher);
            } else if (input.equals("show blocklist")) {
                showingBlockList();
            } else if (input.equals("manage files")) {
                printingString("you are now in directory root");
                FileManagerRun.run(scanner);
            } else if (input.equals("logout")) {
                logout();
                break;
            } else if (input.equals("exit")) {
                System.exit(0);
            } else System.out.println("invalid command");
        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }
}
