package View;

import Model.Select;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static Controller.FileManager.*;
import static java.lang.System.exit;
import static java.lang.System.in;

public class FileManagerRun {
    public static void run(Scanner scanner) {
        Select select = new Select();
        while (true) {
            String input = scanner.nextLine().trim();
            if (input.equals("exit")) {
                System.exit(0);
            } else if (input.matches("create -dir (?<dirname>.*)")) {
                String regex = "create -dir (?<dirname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                creatingDir(matcher, select);
            } else if (input.matches("create -file (?<filename>.*) -format (?<format>.*)")) {
                String regex = "create -file (?<filename>.*) -format (?<format>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                creatingFile(matcher, select);

            } else if (input.equals("show_hidden")) {
                showingHiddenWithoutPass(input, select);
            } else if (input.matches("show_hidden -password (?<userpassword>.*)")) {
                showingHiddenWithPass(input, select);
            } else if (input.matches("cd -name (?<dirname>.*) -jmp")) {
                String regex = "cd -name (?<dirname>.*) -jmp";
                Matcher matcher = getCommandMatcher(input, regex);
                cdWithJump(matcher, select);
            } else if (input.matches("cd -name (?<dirname>.*)") || input.matches("cd (?<dirname>\\.\\.)")) {
                String regex = "cd (?<dirname>\\.\\.)";
                Matcher matcher = getCommandMatcher(input, regex);
                if (matcher.matches())
                    cdwithoutJump(matcher, select);
                else {
                    regex = "cd -name (?<dirname>.*)";
                    matcher = getCommandMatcher(input, regex);
                    cdwithoutJump(matcher, select);
                }
            } else if (input.matches("rename -dir (?<dirname>.*) -new (?<newname>.*)")) {
                String regex = "rename -dir (?<dirname>.*) -new (?<newname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                renameDir(matcher, select);
            } else if (input.matches("rename -file (?<filename>.*) -new (?<newname>.*)")) {
                String regex = "rename -file (?<filename>.*) -new (?<newname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                renamingFile(matcher, select);
            } else if (input.matches("open -name (?<filename>.*)")) {
                String regex = "open -name (?<filename>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                openingFile(matcher, scanner, select);

            } else if (input.matches("select -dir -N (?<number>.*) -names:(?<names>.*)") && !input.endsWith(":")) {
                String regex = "select -dir -N (?<number>.*) -names:(?<names>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                selectDir(matcher, select);
            } else if (input.matches("select -file -N (?<number>.*) -names:(?<names>.*)")) {
                String regex = "select -file -N (?<number>.*) -names:(?<names>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                selectFile(matcher, select);
            } else if (input.matches("delete -files")) {
                deleteFiles(select);
            } else if (input.matches("delete -dir")) {
                deleteDirs(select);
            } else if (input.matches("zip -name (?<zipname>.*)")) {
                String regex = "zip -name (?<zipname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                zipThings(matcher, select);
            } else if (input.matches("unzip -name (?<filename>.*)")) {
                String regex = "unzip -name (?<filename>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                unzipThings(matcher, select);
            } else if (input.matches("show current content")) {
                showContent(select);
            } else if (input.matches("copy -dir (?<dirname>.*)")) {
                String regex = "copy -dir (?<dirname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                copySelectedThings(select, matcher);
            } else if (input.matches("cut -dir (?<dirname>.*)")) {
                String regex = "cut -dir (?<dirname>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                cuttingThings(matcher, select);
            } else if (input.matches("go to user menu")) {
                System.out.println("welcome to user menu");
                break;
            } else if (input.equals("close")) {
                System.out.println("There's no open file");
            } else System.out.println("invalid command");
        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }
}
