package View;

import Model.Directory;
import Model.File;
import Model.Text;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static Controller.Insidefile.*;
import static View.Print.printingString;

public class InsideFileRun {
    private static Text text1;
    private static int flagForApply;
    private static int flagForInvalid;

    public static void run(Scanner scanner, File file) {
        file.getText().setCurserForFirst();
        flagForApply = 0;

        while (true) {
            flagForInvalid = 0;
            String input = scanner.nextLine().trim();
            if (input.equals("close")) {
                flagForInvalid = 1;
                if (flagForApply == 0) {
                    file.getText().setText("");
                }
                printingString("file closed. You are now in directory " + Directory.getCurrentDirectory().getPath());
                break;
            }
            if (!(input.equals("show details")) && !(file.getFileFormat().equals("c") ||
                    file.getFileFormat().equals("txt") ||
                    file.getFileFormat().equals("java"))) {
                printingString("invalid command");
                continue;
            }
            if (input.matches("move_curser -direction (?<direction>.*) -distance (?<distance>.*)")) {
                String regex = "move_curser -direction (?<direction>.*) -distance (?<distance>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                move_Curser(matcher, file);
                flagForInvalid = 1;
            }
            if (input.matches("select -line (?<linenumber>.*) -pos (?<position>.*)")) {
                String regex = "select -line (?<linenumber>.*) -pos (?<position>.*)";
                Matcher matcher = getCommandMatcher(input, regex);
                selectLines(matcher, file);
                flagForInvalid = 1;
            }
            if (input.matches("delete")) {
                deleteText(file);
                if (file.getText() != null)
                    file.getText().takeOutOfSelect();
                flagForInvalid = 1;
            }
            if (input.matches("cut")) {
                cut(file);
                file.getText().takeOutOfSelect();
                flagForInvalid = 1;
            }
            if (input.matches("copy")) {
                copy(file);
                file.getText().takeOutOfSelect();
                flagForInvalid = 1;
            }
            if (input.matches("paste")) {
                paste(file);
                flagForInvalid = 1;
            }
            if (input.matches("write -string \"(?<yourstring>.*)\"")) {
                String regex = "write -string \"(?<yourstring>.*)\"";
                Matcher matcher = getCommandMatcher(input, regex);
                writeThings(file, matcher);
                flagForInvalid = 1;
            }
            if (input.matches("show details")) {
                showingDetails(file);
                flagForInvalid = 1;
            }
            if (input.matches("apply changes for (?<group>.*)")) {
                Matcher matcher = getCommandMatcher(input, "apply changes for (?<group>.*)");
                if (matcher.matches()) {
                    String res = matcher.group("group");
                    printingString("changes applied for " + res);
                    flagForApply = 1;

                }
                flagForInvalid = 1;
            } else if (flagForInvalid == 0) {
                printingString("invalid command");
            }
        }
    }

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }
}

