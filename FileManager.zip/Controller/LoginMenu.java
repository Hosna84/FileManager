package Controller;

import Model.Directory;
import Model.User;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.Print.printingString;

public class LoginMenu {

    private static User userss;

    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    private static boolean isUserNameRepeated(String username) {
        ArrayList<User> users = User.getUsers();
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsername().equals(username)) {
                userss = users.get(i);
                return true;
            }
        }
        return false;
    }

    public static void creatingUser(Matcher matcher, String input) {
        if (matcher.matches()) {
            String username = matcher.group("username");
            String password = matcher.group("password");
            if (isUserNameRepeated(username)) {
                printingString("user already exists");
                return;
            }
            String regex = "[a-zA-Z0-9_]+";
            Matcher matcher1 = getCommandMatcher(username, regex);
            if (!matcher1.matches()) {
                printingString("invalid username format");
                return;
            }
            String regex1 = "(?=.*[a-z]{1,})(?=.*[A-Z]{1,})(?=.*[0-9]{1,}).*";
            Matcher matcher2 = getCommandMatcher(password, regex1);
            if ((!matcher2.matches() || password.length() < 8)) {
                printingString("invalid password");
                return;
            }

            printingString("register successful");
            boolean isOneTime = false;
            if (input.contains("-one_time")) isOneTime = true;
            Directory directory = new Directory("root", "root", null, false);
            User users = new User(username, password, isOneTime, directory);
            users.addDirToWhatIHave(directory);
        }
    }

    public static boolean loginUser(Matcher matcher) {
        if (matcher.matches()) {

            String username = matcher.group("username");
            String password = matcher.group("password");
            if (!isUserNameRepeated(username)) {
                printingString("user doesn't exist");
                return false;
            }
            if (!(userss.getPassword().equals(password))) {
                printingString("password doesn't match");
                return false;
            }
            printingString("login successful");
            User.setLoggedinUser(userss);
            return true;
        }
        return false;
    }
}
