package Controller;

import Model.*;
import View.InsideFileRun;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static View.Print.printingString;
import static View.Print.printingStringBuilder;

public class FileManager {
    private static Matcher getCommandMatcher(String input, String regex) {
        Pattern pattern = Pattern.compile(regex);

        return pattern.matcher(input);
    }

    public static void creatingDir(Matcher matcher, Select select) {
        if (matcher.matches()) {
            String dirName = matcher.group("dirname");
            String path = Directory.getCurrentDirectory().getPath() + "/" + dirName;
            String regex = "^[a-zA-Z0-9.]{1,}(?!=[ ])";
            Matcher matcher1 = getCommandMatcher(dirName, regex);
            if (User.getLoggedInUser().getWhatDirIHave().contains(Directory.getDirByPath(path))) {
                printingString("already exists");
                return;
            }
            if (!matcher1.matches()) {
                printingString("incorrect name format");
                return;
            }
            System.out.println("directory created successfully!");
            select.reduceRound();
            boolean isHeaden = false;
            if (dirName.startsWith(".")) isHeaden = true;
            Directory directory = new Directory(dirName, path, Directory.getCurrentDirectory(), isHeaden);
            Directory.getCurrentDirectory().addToChildrenOfADir(Directory.getCurrentDirectory(), directory);
            User.getLoggedInUser().addDirToWhatIHave(directory);
        }
    }

    public static void creatingFile(Matcher matcher, Select select) {
        if (matcher.matches()) {
            String fileName = matcher.group("filename");
            String format = matcher.group("format");
            if (Directory.getCurrentDirectory() != null) {
                String path = Directory.getCurrentDirectory().getPath() + "/" + fileName + "." + format;
                String regex = "^[a-zA-Z0-9.]{1,}(?!=[ ])";
                Matcher matcher1 = getCommandMatcher(fileName, regex);
                if (User.getLoggedInUser().getWhatFileIHavesIHave().contains(File.getFileByPath(path))) {
                    printingString("already exists");
                    return;
                }
                if (!isFormatValid(format)) {
                    printingString("incorrect format");
                    return;
                }
                if (!matcher1.matches()) {
                    printingString("incorrect name format");
                    return;
                }

                System.out.println("file created successfully!");
                select.reduceRound();
                boolean isHeaden = false;
                if (fileName.startsWith(".")) isHeaden = true;
                File file = new File(fileName, Directory.getCurrentDirectory(), format, isHeaden, false, path);
                User.getLoggedInUser().addFileToWhatIHave(file);
                Directory.getCurrentDirectory().addToChildrenOfADir(Directory.getCurrentDirectory(), file);
            }
        }
    }

    private static boolean isFormatValid(String format) {
        if (format.equals("txt") || format.equals("mkv") || format.equals("mp3") || format.equals("mp4")
                || format.equals("csv") || format.equals("dat") || format.equals("exe") || format.equals("c") || format.equals("java")) {
            return true;
        }
        return false;
    }

    public static void showingHiddenWithoutPass(String input, Select select) {
        if (!isAnyHeaden()) {
            printingString("no hidden item");
            return;
        }
        select.reduceRound();
        makingHeadenList();
    }

    public static void showingHiddenWithPass(String input, Select select) {
        String regex = "show_hidden -password (?<userpassword>.*)";
        Matcher matcher = getCommandMatcher(input, regex);
        if (matcher.matches()) {
            String password = matcher.group("userpassword");
            if (!User.getLoggedInUser().getPassword().equals(password)) {
                printingString("invalid password");
                return;
            }
            if (!isAnyHeaden()) {
                printingString("no hidden item");
                return;
            }
            select.reduceRound();
            makingHeadenList();
        }
    }

    private static void makingHeadenList() {
        StringBuilder result = new StringBuilder();
        int index = 1;
        result.append("dir:" + "\n");
        ArrayList<File> files = User.getLoggedInUser().getWhatFileIHavesIHave();
        ArrayList<Directory> directories = User.getLoggedInUser().getWhatDirIHave();
        for (int i = 0; i < directories.size(); i++) {
            if (directories.get(i).getDirName().startsWith(".")) {
                result.append(index + ". " + directories.get(i).getPath() + "\n");
                index++;
            }
        }
        index = 1;
        result.append("file:" + "\n");
        for (int i = 0; i < files.size(); i++) {
            if (getFileName(files.get(i).getPath()).startsWith(".") && !files.get(i).getIsZip()) {
                result.append(index + ". " + files.get(i).getPath() + "\n");
                index++;
            }
        }
        index = 1;
        result.append("zip:" + "\n");
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().startsWith(".") && files.get(i).getIsZip()) {
                result.append(index + ". " + files.get(i).getPath() + "\n");
                index++;
            }
        }
        printingStringBuilder(result);
    }

    private static boolean isAnyHeaden() {
        ArrayList<File> files = User.getLoggedInUser().getWhatFileIHavesIHave();
        ArrayList<Directory> directories = User.getLoggedInUser().getWhatDirIHave();
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().startsWith(".")) return true;
        }
        for (int j = 0; j < directories.size(); j++) {
            if (directories.get(j).getDirName().startsWith(".")) return true;
        }
        return false;
    }

    private static boolean doWeHaveThisDirInRoot(String diePath) {
        ArrayList<Directory> directories = User.getLoggedInUser().getDirByPath("root").getDirChildren();
        for (int i = 0; i < directories.size(); i++) {
            if (directories.get(i).getPath().equals(diePath))
                return true;
        }
        return false;
    }

    public static void cdwithoutJump(Matcher matcher, Select select) {
        if (matcher.matches()) {
            String dirName = matcher.group("dirname");
            ArrayList<Directory> directories = User.getLoggedInUser().getWhatDirIHave();
            int error = 0;
            if (error == 0 && Directory.getDirByPath(dirName) == null &&
                    !dirName.equals("..")) {
                printingString("unable to open directory");
                printingString("no such directory");
                error = 1;
            }
            if (error == 0 && extractDirName(matcher.group("dirname")) != null &&
                    extractDirName(matcher.group("dirname")).startsWith(".") &&
                    !matcher.group("dirname").equals("..")) {
                printingString("unable to open directory");
                printingString("hidden directory");
                error = 1;
            }
            if (Directory.getCurrentDirectory() != null) {
                if (Directory.getCurrentDirectory().getDirChildren() != null) {
                    if (error == 0 && !dirName.equals("..") && (((Directory.getCurrentDirectory().getPath().equals("root") && !doWeHaveThisDirInRoot(dirName)) ||
                            (Directory.getCurrentDirectory().getParent() != null &&
                                    !Directory.getCurrentDirectory().getParent().equals(Directory.getDirByPath(dirName)) &&
                                    !Directory.getCurrentDirectory().getDirChildren().contains(Directory.getDirByPath(dirName)))))) {
                        printingString("unable to open directory");
                        printingString("too deep");
                        error = 1;
                    }
                }
            }
            if (matcher.group("dirname").equals("..")) {
                if (Directory.getCurrentDirectory().getDirName().equals("root")) {
                    printingString("root doesn't have parent node");
                    error = 1;
                } else {
                    if (Directory.getCurrentDirectory().getParent() != null) {
                        printingString("entered directory " + Directory.getCurrentDirectory().getParent().getPath());
                        Directory.setCurrentDirectory(Directory.getCurrentDirectory().getParent());
                        select.reduceRound();
                    }
                }
            }

            if (error == 0 && !matcher.group("dirname").equals("..")) {
                Directory.setCurrentDirectory(Directory.getDirByPath(dirName));
                select.reduceRound();
                if (Directory.getCurrentDirectory() != null) {
                    printingString("entered directory " + matcher.group("dirname"));
                    select.reduceRound();
                }
            }
        }
    }

    public static void cdWithJump(Matcher matcher, Select select) {
        if (matcher.matches()) {
            String dirName = matcher.group("dirname");

            int error = 0;
            if (error == 0 && !User.getLoggedInUser().getWhatDirIHave().contains(Directory.getDirByPath(dirName)) && !matcher.group("dirname").equals("..")) {
                printingString("unable to open directory");
                System.out.println("no such directory");
                error = 1;
            }
            if (error == 0 && matcher.group("dirname").equals("..") && Directory.getCurrentDirectory().getDirName().equals("root")) {
                System.out.println("root doesn't have parent node");
                error = 1;
            }
            if (matcher.group("dirname").equals("..")) {

                if (error == 0) {
                    select.reduceRound();
                    System.out.println("entered directory " + Directory.getCurrentDirectory().getParent().getPath());
                    Directory.setCurrentDirectory(Directory.getCurrentDirectory().getParent());
                }
            }
            if (error == 0 && !matcher.group("dirname").equals("..")) {
                select.reduceRound();
                Directory.setCurrentDirectory(Directory.getDirByPath(dirName));
                System.out.println("entered directory " + dirName);
            }
        }
    }

    public static void renameDir(Matcher matcher, Select select) {

        if (matcher.matches()) {

            int error = 0;
            String dirname = matcher.group("dirname");
            String newname = matcher.group("newname");
            if (dirname.equals(newname)) {
                error = 1;
                System.out.println("same name!");
            }
            if (error == 0 &&
                    !User.getLoggedInUser().getWhatDirIHave().contains(Directory.getDirByPath(dirname))) {
                System.out.println("no such directory");
                error = 1;
            }
            if (error == 0 && isThisDirNameRepeated(newname)) {
                System.out.println("name is already taken");
                error = 1;
            }
            if (error == 0) {
                System.out.println("renamed successfully");
                select.reduceRound();
                renamingDirAtEnd(newname, dirname);
            }
        }
    }

    private static void renamingDirAtEnd(String newname, String dirname) {
        if (extractDirName(newname).startsWith(".")) {
            Directory.getDirByPath(dirname).setIsHeaden(true);
            Directory.getDirByPath(dirname).setDirName(extractDirName(newname));
            Directory.getDirByPath(dirname).setPath(newname);
        } else {
            Directory.getDirByPath(dirname).setDirName(extractDirName(newname));
            Directory.getDirByPath(dirname).setPath(newname);
            ArrayList<Directory> directories = User.getLoggedInUser().getWhatDirIHave();
            ArrayList<File> files = User.getLoggedInUser().getWhatFileIHavesIHave();
            for (int i = 0; i < directories.size(); i++) {
                if (directories.get(i).getParent() != null) {
                    if (directories.get(i).getParent().getPath().equals(newname))
                        directories.get(i).setPath(newname + "/" + directories.get(i).getDirName());
                }
            }
            for (int i = 0; i < files.size(); i++) {
                if (files.get(i).getParent() != null) {
                    if (files.get(i).getParent().getPath().equals(newname))
                        files.get(i).setPath(newname + "/" + files.get(i).getFileName() +
                                "." + files.get(i).getFileFormat());
                }
            }

        }
    }

    private static String extractDirName(String filePath) {
        String[] parts = filePath.split("/");
        if (parts.length >= 2) {
            return parts[parts.length - 1]; // Assuming the directory name is the second last part
        } else {
            return null; // Not enough parts to extract directory name

        }
    }

    private static boolean isThisDirNameRepeated(String dirPath) {
        ArrayList<Directory> directories = User.getLoggedInUser().getWhatDirIHave();
        for (int i = 0; i < directories.size(); i++) {
            if (directories.get(i).getPath().equals(dirPath)) return true;
        }
        return false;
    }

    public static void renamingFile(Matcher matcher, Select select) {
        if (matcher.matches()) {
            int error = 0;
            String filename = matcher.group("filename");
            String newname = matcher.group("newname");
            if (newname.equals(filename)) {
                System.out.println("same name!");
                error = 1;
            }
            if (error == 0 && !User.getLoggedInUser().getWhatFileIHavesIHave().contains(File.getFileByPath(filename))) {
                System.out.println("no such file");
                error = 1;
            }
            if (error == 0 && isThisFileNameRepeated(newname)) {
                System.out.println("name is already taken");
                error = 1;
            }
            if (error == 0) {
                System.out.println("renamed successfully");
                select.reduceRound();
                if (newname.startsWith(".")) {
                    File.getFileByPath(filename).setIsHeaden(true);
                    File.getFileByPath(filename).setFileName(getFileName(filename));
                    File.getFileByPath(filename).setPath(newname);
                } else {
                    File.getFileByPath(filename).setFileName(getFileName(filename));
                    File.getFileByPath(filename).setPath(newname);
                }
            }
        }
    }

    private static String getFileName(String filePath) {
        String regex = "([^/\\\\]+)\\.[^/\\\\.]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(filePath);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private static boolean isThisFileNameRepeated(String fileName) {
        ArrayList<File> files = User.getLoggedInUser().getWhatFileIHavesIHave();
        for (int d = 0; d < files.size(); d++) {
            if (files.get(d).getPath().equals(fileName)) return true;
        }
        return false;
    }

    public static void openingFile(Matcher matcher, Scanner scanner, Select select) {
        if (matcher.matches()) {
            String filename = matcher.group("filename");
            int error = 0;
            if (!User.getLoggedInUser().getWhatFileIHavesIHave().contains(User.getLoggedInUser().getFileByPath(filename))) {
                System.out.println("no such file");
                error = 1;
            }
            if (error == 0 && (getFileName(filename).startsWith(".") || User.getLoggedInUser().getFileByPath(filename).getIsZip())) {
                printingString("unable to open file");
                error = 1;
            }
            if (error == 0) {
                select.reduceRound();
                System.out.println("entered file " + filename);
                User.getLoggedInUser().getFileByPath(filename).setOriginalText(User.getLoggedInUser().getFileByPath(filename).getText());
                InsideFileRun.run(scanner, User.getLoggedInUser().getFileByPath(filename));
            }
        }
    }

    public static void selectDir(Matcher matcher, Select select) {
        if (matcher.matches()) {
            int numberOfDirs = Integer.parseInt(matcher.group("number"));
            String fileNames = matcher.group("names");
            String[] filenames = fileNames.split(",");

            int error = 0;
            if (!(1 <= numberOfDirs && numberOfDirs <= 9)) {
                System.out.println("invalid number");
                error = 1;
            }
            if (filenames.length != numberOfDirs && error == 0) {
                System.out.println("invalid number of arguments");
                error = 1;
            }
            if (error == 0) {

                boolean isError = doWeHaveNotExistedDir(filenames);
                if (isError) error = 1;
            }
            if (error == 0) {
                System.out.println("selected successfully");
                select.reduceRound();
                ArrayList<Directory> directories = new ArrayList<>();
                for (int i = 0; i < numberOfDirs; i++) {
                    directories.add(Directory.getDirByPath(filenames[i]));
                }
                select.changeSelectedDirs(directories);
            }
        }
    }

    private static boolean doWeHaveNotExistedDir(String[] fileNames) {
        boolean print = false;
        for (int i = 0; i < fileNames.length; i++) {

            if (!User.getLoggedInUser().getWhatDirIHave().contains(Directory.getDirByPath(fileNames[i]))) {
                System.out.println("directory " + fileNames[i] + " doesn't exist");
                print = true;
            }
        }
        return print;
    }

    private static boolean doWeHaveNotExistedFile(String[] fileNames) {
        boolean print = true;
        for (int i = 0; i < fileNames.length; i++) {
            if (!Directory.getCurrentDirectory().getFileChildren().contains(User.getLoggedInUser().getFileByPath(fileNames[i])) || getFileName(fileNames[i]).startsWith(".")) {
                System.out.println("file " + fileNames[i] + " doesn't exist");
                print = false;
            }
        }
        return print;
    }

    public static void selectFile(Matcher matcher, Select select) {
        if (matcher.matches()) {
            int numberOfFiles = Integer.parseInt(matcher.group("number"));
            String fileNames = matcher.group("names");
            String[] filenames = fileNames.split(",");
            int error = 0;
            if (!(1 <= numberOfFiles && numberOfFiles <= 9)) {
                System.out.println("invalid number");
                error = 1;
            }
            if (filenames.length != numberOfFiles && error == 0) {
                System.out.println("invalid number of arguments");
                error = 1;
            }
            if (error == 0) {
                boolean isError = doWeHaveNotExistedFile(filenames);
                if (!isError) error = 1;
            }
            if (error == 0) {
                System.out.println("selected successfully");
                select.reduceRound();
                ArrayList<File> files = new ArrayList<>();
                for (int i = 0; i < numberOfFiles; i++) {
                    files.add(File.getFileByPath(filenames[i]));
                }
                select.changeSelectedFiles(files);
            }
        }
    }

    public static void deleteFiles(Select select) {
        select.reduceRound();
        ArrayList<File> files = select.getSelctedFiles();
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getRound() == 0) {
                printingString("no file selected");
                return;
            }
        }
        if (select.getSelctedFiles().size() == 0) {
            printingString("no file selected");
            return;
        }

        for (int i = 0; i < files.size(); i++) {
            if (files.get(i) != null) {
                File.removeFromAllFiles(files.get(i));
                files.get(i).getParent().removeFileFromChildrenFiles(files.get(i));
                User.getLoggedInUser().removeFromFilesIHave(files.get(i));
            }
        }
        ArrayList<File> files1 = new ArrayList<>();
        select.changeSelectedFiles(files1);
        System.out.println("deleted successfully");
    }

    public static void deleteDirs(Select select) {
        select.reduceRound();
        ArrayList<Directory> directories = select.getSelectedDirs();
        for (int i = 0; i < directories.size(); i++) {
            if (directories.get(i).getRound() == 0) {
                printingString("no directory selected");
                return;
            }
        }
        if (select.getSelectedDirs().size() == 0) {
            System.out.println("no directory selected");
            return;
        }
        for (int i = 0; i < directories.size(); i++) {
            deleteDir(directories.get(i), select);
        }

        System.out.println("deleted successfully");
    }

    private static void deleteDir(Directory directory, Select select) {
        if (directory != null) {
            ArrayList<File> files = directory.getFileChildren();
            ArrayList<Directory> directories = directory.getDirChildren();
            if (files != null) {
                for (int y = 0; y < files.size(); y++) {
                    deleteFile(files.get(y), select);
                }
            }
            if (directories != null) {
                for (int q = 0; q < directories.size(); q++) {
                    Directory.removeFromDirs(directories.get(q));
                    directory.getParent().removeDirFromChildren(directories.get(q));
                    User.getLoggedInUser().removeFromDirsIHave(directories.get(q));
                    select.removwFromSelectedDirs(directories.get(q));
                    deleteDir(directories.get(q), select);
                }
            }
            Directory.removeFromDirs(directory);
            directory.getParent().removeDirFromChildren(directory);
            User.getLoggedInUser().removeFromDirsIHave(directory);
            select.removwFromSelectedDirs(directory);
        }
    }

    private static void deleteDirForZip(Directory directory) {
        Directory.removeFromDirs(directory);
        directory.getParent().removeDirFromChildren(directory);
        User.getLoggedInUser().removeFromDirsIHave(directory);
    }

    private static void deleteFile(File file, Select select) {
        if (file != null) {
            File.removeFromAllFiles(file);
            file.getParent().removeFileFromChildrenFiles(file);
            User.getLoggedInUser().removeFromFilesIHave(file);
            select.removeFromSelectedFiles(file);
        }
    }

    private static void deleteFileforZip(File file) {
        if (file != null) {
            File.removeFromAllFiles(file);
            file.getParent().removeFileFromChildrenFiles(file);
            User.getLoggedInUser().removeFromFilesIHave(file);

        }
    }

    public static void zipThings(Matcher matcher, Select select) {
        if (matcher.matches()) {

            String zipName = matcher.group("zipname");
            String regex = "[a-zA-Z0-9.]{1}[^ ]*";
            Matcher matcher1 = getCommandMatcher(zipName, regex);
            if (isThisZiprepeated(zipName)) {
                printingString("file already exists");
                return;
            }
            if (select.getSelctedFiles().size() == 0 && select.getSelectedDirs().size() == 0) {
                printingString("nothing to zip");
                return;
            }
            if (!matcher1.matches()) {
                System.out.println("incorrect name format");
                return;
            }
            boolean isHeaden = false;
            if (zipName.startsWith(".")) isHeaden = true;
            if (Directory.getCurrentDirectory() != null) {
                Zip zip = new Zip(zipName, Directory.getCurrentDirectory(), "zip", isHeaden, true,
                        Directory.getCurrentDirectory().getPath() + "/" + zipName + ".zip", select.getSelctedFiles(), select.getSelectedDirs());
                Directory.getCurrentDirectory().addToChildrenOfADir(Directory.getCurrentDirectory(), zip);

                ArrayList<File> selectedFiles = select.getSelctedFiles();
                for (int e = 0; e < selectedFiles.size(); e++) {
                    deleteFileforZip(selectedFiles.get(e));
                }
                ArrayList<File> files = new ArrayList<>();
                select.changeSelectedFiles(files);
                ArrayList<Directory> selectedDirs = select.getSelectedDirs();

                for (int w = 0; w < selectedDirs.size(); w++) {

                    deleteDirForZip(selectedDirs.get(w));
                }
                ArrayList<Directory> directories = new ArrayList<>();
                select.changeSelectedDirs(directories);
                printingString("zipped successfully");
                select.reduceRound();
            }
        }
    }

    private static boolean isThisZiprepeated(String zipName) {
        ArrayList<File> files = User.getLoggedInUser().getWhatFileIHavesIHave();
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().equals(zipName) && files.get(i).getFileFormat().equals("zip"))
                return true;
        }
        return false;
    }

    public static void unzipThings(Matcher matcher, Select select) {
        if (matcher.matches()) {
            String fileName = matcher.group("filename");
            if (File.getFileByPath(fileName) == null) {
                printingString("no such file or directory");
                return;
            }
            File file = File.getFileByPath(fileName);
            if (file instanceof Zip) {
                Zip zip = (Zip) file;
                if (zip != null) {
                    ArrayList<File> zippedFiles = zip.getFilesInZip();
                    ArrayList<Directory> zippedDirs = zip.getDirsInZip();
                    for (int i = 0; i < zippedFiles.size(); i++) {
                        unZipFiles(zippedFiles.get(i));
                    }
                    for (int d = 0; d < zippedDirs.size(); d++) {
                        unZipDirs(zippedDirs.get(d));
                    }
                    deleteFileforZip(File.getFileByPath(fileName));
                    printingString("unzipped successfully");
                    select.reduceRound();
                }
            }
        }
    }

    private static void unZipDirs(Directory directory) {
        ArrayList<File> filesInZip = directory.getFileChildren();
        ArrayList<Directory> dirsInZip = directory.getDirChildren();
        for (int g = 0; g < filesInZip.size(); g++) {
            unZipFiles(filesInZip.get(g));
        }
        for (int o = 0; o < dirsInZip.size(); o++) {
            Directory.addToAllDirs(dirsInZip.get(o));
            dirsInZip.get(o).setPath(Directory.getCurrentDirectory().getPath() + "/" + dirsInZip.get(o).getDirName());
            Directory.getCurrentDirectory().addToChildrenOfADir(Directory.getCurrentDirectory(), dirsInZip.get(o));
            User.getLoggedInUser().addDirToWhatIHave(dirsInZip.get(o));
            unZipDirs(dirsInZip.get(o));
        }
        Directory.addToAllDirs(directory);
        directory.setPath(Directory.getCurrentDirectory().getPath() + "/" + directory.getDirName());
        Directory.getCurrentDirectory().addToChildrenOfADir(Directory.getCurrentDirectory(), directory);
        User.getLoggedInUser().addDirToWhatIHave(directory);
    }

    private static void unZipFiles(File file) {
        File.setAllFiles(file);
        file.setPath(Directory.getCurrentDirectory().getPath() + "/" + file.getFileName() + "." + file.getFileFormat());
        Directory.getCurrentDirectory().addToChildrenOfADir(Directory.getCurrentDirectory(), file);
        User.getLoggedInUser().addFileToWhatIHave(file);
    }


    public static void showContent(Select select) {
        if (Directory.getCurrentDirectory() != null) {
            ArrayList<Directory> directories = Directory.getCurrentDirectory().getDirChildren();
            ArrayList<File> files = Directory.getCurrentDirectory().getFileChildren();
            if ((directories == null && files == null) ||
                    (directories.isEmpty() && files.isEmpty()) ||
                    (directories.size() == 0 && files.size() == 0)) {
                printingString("directory empty");
                return;
            }
            int index = 1;
            StringBuilder result = new StringBuilder();
            result.append("dir:" + "\n");

            for (int i = 0; i < directories.size(); i++) {
                result.append(index + ". " + directories.get(i).getPath() + "\n");
                index++;
            }
            index = 1;
            result.append("file:" + "\n");

            for (int j = 0; j < files.size(); j++) {
                if (!files.get(j).getIsZip()) {
                    result.append(index + ". " + files.get(j).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("zip:" + "\n");
            for (int s = 0; s < files.size(); s++) {
                if (files.get(s).getIsZip()) {
                    result.append(index + ". " + files.get(s).getPath() + "\n");
                    index++;
                }
            }
            printingStringBuilder(result);
            select.reduceRound();
        }
    }

    public static void copySelectedThings(Select select, Matcher matcher) {
        if (matcher.matches()) {
            String dirPath = matcher.group("dirname");
            ArrayList<File> selectedFiles = select.getSelctedFiles();
            ArrayList<Directory> selectedDirs = select.getSelectedDirs();
            if (!doWeHaveAnySelectedFileOrDir(selectedFiles, selectedDirs)) {
                printingString("nothing selected");
                return;
            }
            if (selectedDirs.size() == 0 && selectedFiles.size() == 0) {
                printingString("nothing selected");
                return;
            }
            if (!User.getLoggedInUser().getWhatDirIHave().contains(User.getLoggedInUser().getDirByPath(dirPath)) ||
                    dirPath.startsWith(".")) {
                printingString("invalid destination");
                return;
            }
            for (int j = 0; j < selectedDirs.size(); j++) {
                if (doWeHaveThisDirInDesOrNot(selectedDirs.get(j), dirPath)) {
                    printingString("can't do action with a selected directory as destination");
                    return;
                }
            }
            Directory detenation = User.getLoggedInUser().getDirByPath(dirPath);
            copyThibngsToDesDir(detenation, selectedFiles, selectedDirs);
            printingString("copy successfully");
            select.reduceRound();
        }
    }

    private static boolean doWeHaveThisDirInDesOrNot(Directory selectedDir, String path) {
        if (selectedDir.equals(Directory.getDirByPath(path))) return true;
        return false;
    }

    private static void copyThibngsToDesDir(Directory destanation, ArrayList<File> selectedFiles, ArrayList<Directory> selectedDirs) {
        ArrayList<File> filesInDesDir = destanation.getFileChildren();
        ArrayList<Directory> dirsInDesDir = destanation.getDirChildren();
        ArrayList<String> fileNames = new ArrayList<>();
        ArrayList<String> dirNames = new ArrayList<>();
        for (int i = 0; i < selectedFiles.size(); i++) {
            int flag = 0;
            for (int j = 0; j < filesInDesDir.size(); j++) {
                if (filesInDesDir.get(j).getFileName().equals(selectedFiles.get(i).getFileName()) && flag == 0) {
                    fileNames.add(selectedFiles.get(i).getFileName() + "_" + Directory.getCurrentDirectory().getDirName());
                    flag = 1;
                    continue;
                }
            }
            if (flag == 0) {
                fileNames.add(selectedFiles.get(i).getFileName() + "." + selectedFiles.get(i).getFileFormat());
            }

        }
        for (int i = 0; i < selectedDirs.size(); i++) {
            int flag = 0;
            for (int j = 0; j < dirsInDesDir.size(); j++) {
                if (dirsInDesDir.get(j).getDirName().equals(selectedDirs.get(i).getDirName())) {
                    dirNames.add(selectedDirs.get(i).getDirName() + "_" + Directory.getCurrentDirectory().getDirName());
                    flag = 1;
                    continue;
                }
            }
            if (flag == 0) dirNames.add(selectedDirs.get(i).getDirName());
        }
        for (int i = 0; i < selectedFiles.size(); i++) {
            if (fileNames.size() == selectedFiles.size()) {
                copingFiles(fileNames.get(i), destanation, selectedFiles.get(i));
            }
        }
        Directory parent = destanation;
        for (int i = 0; i < selectedDirs.size(); i++) {
            if (dirNames.size() == selectedDirs.size())
                copyingDirs(parent, selectedDirs.get(i), dirNames.get(i));
        }
    }

    private static void copyingDirs(Directory parent, Directory wantToBeCopied, String dirName) {
        boolean isHeaden = false;
        if (extractDirName(dirName) != null) {
            if (extractDirName(dirName).startsWith(".")) isHeaden = true;
        }

        Directory directory = new Directory(dirName, parent.getPath() + "/" + dirName, parent, isHeaden);
        parent.addToChildrenOfADir(parent, directory);

        User.getLoggedInUser().setWhatDirIHave(directory);
        for (File file : wantToBeCopied.getFileChildren()) {
            copingFiles(file.getFileName(), directory, file);
        }
        for (Directory directory1 : wantToBeCopied.getDirChildren()) {
            copyingDirs(directory, directory1, directory1.getDirName());
        }
    }

    private static void copingFiles(String fileName, Directory parent, File selectedFile) {
        boolean isHeaden = false;
        if (fileName.startsWith(".")) isHeaden = true;
        if (!selectedFile.getIsZip()) {
            File file = new File(fileName, parent, selectedFile.getFileFormat(),
                    isHeaden, selectedFile.getIsZip(), parent.getPath() + "/" + fileName + "." + selectedFile.getFileFormat());
            User.getLoggedInUser().addFileToWhatIHave(file);
            parent.addToChildrenOfADir(parent, file);
        } else {
            Zip zip1 = (Zip) selectedFile;
            Zip zip = new Zip(fileName, parent, selectedFile.getFileFormat(),
                    isHeaden, selectedFile.getIsZip(), parent.getPath() + "/" + fileName + "." + selectedFile.getFileFormat(), zip1.getFilesInZip(), zip1.getDirsInZip());
            User.getLoggedInUser().addFileToWhatIHave((File) zip);
            parent.addToChildrenOfADir(parent, (File) zip);
        }
    }

    private static boolean doWeHaveAnySelectedFileOrDir(ArrayList<File> files, ArrayList<Directory> directories) {
        boolean file = true;
        boolean dir = true;
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getRound() == 0)
                file = false;
        }
        for (int i = 0; i < directories.size(); i++) {
            if (directories.get(i).getRound() == 0)
                dir = false;
        }
        if (files.size() == 0) file = false;
        if (directories.size() == 0) dir = true;
        if (!dir && !file)
            return false;
        return true;
    }

    public static void cuttingThings(Matcher matcher, Select select) {
        if (matcher.matches()) {
            String dirPath = matcher.group("dirname");
            ArrayList<File> selectedFiles = select.getSelctedFiles();
            ArrayList<Directory> selectedDirs = select.getSelectedDirs();
            if (!doWeHaveAnySelectedFileOrDir(selectedFiles, selectedDirs)) {
                printingString("nothing selected");
                return;
            }
            if (selectedDirs.size() == 0 && selectedFiles.size() == 0) {
                printingString("nothing selected");
                return;
            }
            if (!User.getLoggedInUser().getWhatDirIHave().contains(User.getLoggedInUser().getDirByPath(dirPath)) ||
                    dirPath.startsWith(".")) {
                printingString("invalid destination");
                return;
            }
            for (int j = 0; j < selectedDirs.size(); j++) {
                if (doWeHaveThisDirInDesOrNot(selectedDirs.get(j), dirPath)) {
                    printingString("can't do action with a selected directory as destination");
                    return;
                }
            }

            Directory detenation = Directory.getDirByPath(dirPath);
            cutThibngsToDesDir(detenation, select.getSelctedFiles(), select.getSelectedDirs());
            select.reduceRound();
            printingString("cut successfully");

        }
    }

    private static void cutThibngsToDesDir(Directory destanation, ArrayList<File> selectedFiles, ArrayList<Directory> selectedDirs) {
        ArrayList<File> filesInDesDir = destanation.getFileChildren();
        ArrayList<Directory> dirsInDesDir = destanation.getDirChildren();
        ArrayList<String> fileNames = new ArrayList<>();
        ArrayList<String> dirNames = new ArrayList<>();
        for (int i = 0; i < selectedFiles.size(); i++) {
            for (int j = 0; j < filesInDesDir.size(); j++) {
                if (filesInDesDir.get(j).getFileName().equals(selectedFiles.get(i).getFileName())) {
                    fileNames.add(selectedFiles.get(i).getFileName() + "." + selectedFiles.get(i).getFileFormat() +
                            "_" + Directory.getCurrentDirectory().getDirName());
                } else fileNames.add(selectedFiles.get(i).getFileName());
            }
        }
        for (int i = 0; i < selectedDirs.size(); i++) {
            if (dirsInDesDir.size() != 0) {
                for (int j = 0; j < dirsInDesDir.size(); j++) {
                    if (dirsInDesDir.get(j).getDirName().equals(selectedDirs.get(i).getDirName())) {
                        dirNames.add(selectedDirs.get(i).getDirName() + "_" + Directory.getCurrentDirectory().getDirName());
                    } else dirNames.add(selectedDirs.get(i).getDirName());

                }
            } else dirNames.add(selectedDirs.get(i).getDirName());
        }
        for (int i = 0; i < selectedFiles.size(); i++) {
            cuttingFiles(selectedFiles.get(i), destanation, fileNames.get(i));
        }
        Directory parent = destanation;
        if (selectedDirs.size() == dirNames.size()) {
            for (int j = 0; j < selectedDirs.size(); j++) {
                cuttingDirs(selectedDirs.get(j), parent, dirNames.get(j));
            }
        }
    }

    private static void cuttingFiles(File fileToBeCut, Directory destenation, String fileName) {
        fileToBeCut.setFileName(fileName);
        fileToBeCut.setPath(destenation.getPath() + "/" + fileToBeCut.getFileName() + "." + fileToBeCut.getFileFormat());
        destenation.addToChildrenOfADir(destenation, fileToBeCut);
        fileToBeCut.getParent().removeFileFromChildrenFiles(fileToBeCut);
        fileToBeCut.setParent(destenation);
        System.out.println("931" + fileToBeCut.getPath());
    }

    private static void cuttingDirs(Directory directory, Directory destenation, String dirName) {
        directory.setDirName(dirName);
        directory.setPath(destenation.getPath() + "/" + dirName);
        destenation.addToChildrenOfADir(destenation, directory);
        directory.getParent().removeDirFromChildren(directory);
        directory.setParent(destenation);
        for (File file : directory.getFileChildren()) {
            cuttingFiles(file, directory, file.getFileName());
        }
        for (Directory directory1 : directory.getDirChildren()) {
            if (directory1 != null && directory != null && directory1.getDirName() != null)
                cuttingDirs(directory1, directory, directory1.getDirName());
        }
    }
}