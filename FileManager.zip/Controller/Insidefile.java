package Controller;

import Model.File;
import Model.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;

import static View.Print.printingString;
import static View.Print.printingStringBuilder;

public class Insidefile {
    public static void move_Curser(Matcher matcher, File file) {
        if (matcher.matches()) {
            String direction = matcher.group("direction");
            int distance = Integer.parseInt(matcher.group("distance"));
            if (!(direction.equals("up") || direction.equals("down") ||
                    direction.equals("left") || direction.equals("right"))) {
                printingString("invalid direction");
                return;
            }
            if (!(distance >= 1 && distance <= 10)) {
                printingString("invalid distance");
                return;
            }
            if (isThisOutOfBoudOrNot(direction, distance, file)) {
                printingString("curser out of bounds");
                return;
            }
            if (file.getText() != null) {
                printingString("curser is in line " + getLine(file.getText().getCurserIndex(), file.getText().getText()) + " and position " +
                        getPosition(file.getText().getCurserIndex(), file.getText().getText()));
            }
        }
    }

    private static int getPosition(int index, String text) {
        int pos = 0;
        for (int i = index; i >= 0; i--) {

            if (text != null && text.length() - 1 >= i) {
                if (text.charAt(i) != '\n') {
                    pos++;
                }
                if (text.charAt(i) == '\n') break;
            }
        }

        return pos - 1;
    }

    private static int getLine(int index, String text) {
        int lineNum = 1;
        for (int i = 0; i < index; i++) {
            if (text != null && i <= text.length() - 1) {
                if (text.charAt(i) == '\n') lineNum++;
            }
        }
        return lineNum;
    }

    private static int howManyLinesDoWeHaveInText(String text) {
        int lineNum = 1;
        if (text != null) {
            for (int i = 0; i < text.length(); i++) {
                if (text.charAt(i) == '\n') lineNum++;
            }
        }
        return lineNum;
    }

    private static boolean isThisOutOfBoudOrNot(String direction, int distance, File file) {
        if (file.getText() != null) {
            int newLine = getLine(file.getText().getCurserIndex(), file.getText().getText());
            int newPosition = file.getText().getCurserIndex();
            if (newPosition == 0) return true;
            switch (direction) {
                case "up":
                    newLine -= distance;
                    newPosition = getIndex(newLine, getPosition(file.getText().getCurserIndex(), file.getText().getText()), file.getText().getText());
                    newPosition++;
                    break;
                case "down":
                    newLine += distance;

                    newPosition = getIndex(newLine, getPosition(file.getText().getCurserIndex(), file.getText().getText()), file.getText().getText());
                    break;
                case "left":
                    newPosition -= distance;
                    break;
                case "right":
                    newPosition += distance;
                    break;
            }
            if ((file.getText() != null && file.getText().getText() != null && file.getText().getText().isEmpty())
                    || (newLine <= 0 || newLine > howManyLinesDoWeHaveInText(file.getText().getText())
                    || newPosition < 0 ||
                    (file.getText().getText() != null && newPosition > file.getText().getText().length() - 1))) {
                return true;
            }
            file.getText().setCurserIndex(newPosition);
        }
        if (file.getText() == null) return true;
        return false;
    }

    private static int getIndex(int lineNum, int position, String text) {
        int finalIdx = 0;
        int lineCounter = 0;
        int tmp = 0;
        if (text != null) {
            if (lineNum != 1) for (int j = 0; j < text.length(); j++) {
                finalIdx++;
                if (text.charAt(j) == '\n') {
                    lineCounter++;
                    if (lineCounter >= lineNum - 1) break;
                }
            }
            if (position != 0) for (int i = finalIdx; i < text.length(); i++) {
                finalIdx++;
                tmp++;
                if (tmp == position || text.charAt(i) == '\n') break;
            }
        }
        return finalIdx;

    }

    public static void selectLines(Matcher matcher, File file) {
        if (matcher.matches()) {
            int lineNum = Integer.parseInt(matcher.group("linenumber"));
            int position = Integer.parseInt(matcher.group("position"));
            if (file.getText() != null) {
                String text = file.getText().getText();
                if (text != null) {
                    String[] saparetedText = text.split("\n");
                    if (lineNum > howManyLinesDoWeHaveInText(file.getText().getText()) || position > saparetedText[lineNum - 1].length()) {
                        printingString("position out of bounds");
                        return;
                    }
                }
                file.getText().setSelectedThings(lineNum, position);
                printingString("selected successfully");
            }
        }
    }

    public static void deleteText(File file) {
        if (file.getText() != null && file.getText().getSelectedUntilThisLineNum() == 0 && file.getText().getSelectedUntilThisPosition() == 0) {
            printingString("nothing to delete");
            return;
        }
        if (file.getText() != null) {
            int start = Math.min(file.getText().getCurserIndex(), gainEnd(file.getText().getSelectedUntilThisLineNum(),
                    file.getText().getSelectedUntilThisPosition(), file.getText().getText()));
            int end = Math.max(file.getText().getCurserIndex(), gainEnd(file.getText().getSelectedUntilThisLineNum(),
                    file.getText().getSelectedUntilThisPosition(), file.getText().getText()));
            if (file.getText().getSelectedUntilThisLineNum() == 1 && file.getText().getSelectedUntilThisPosition() == 0)
                start = 0;
            deleteFromText(file, file.getText().getText(), start, end);
            printingString("deleted successfully");
        }
    }

    private static int gainEnd(int lineNum, int position, String text) {
        int lineCounter = 1;
        int countForPos = 0;
        int finalPos = -1;
        if (text != null) {
            for (int i = 0; i < text.length(); i++) {
                if (lineCounter == lineNum && position == countForPos)
                    break;
                if (lineCounter == lineNum) countForPos++;
                if (text.charAt(i) == '\n') lineCounter++;
                finalPos++;
            }
        }
        return finalPos + 1;
    }

    private static void deleteFromText(File file, String line, int start, int end) {
        StringBuilder result = new StringBuilder();
        String text = file.getText().getText();
        for (int i = 0; i < start; i++) {
            result.append(text.charAt(i));
        }
        if (text != null) {
            for (int i = end; i < text.length(); i++) {
                result.append(text.charAt(i));
            }
        }
        file.getText().setText(result.toString());
    }

    private static int getIndexx(int lineNum, int position, File file) {
        int index = 0;

        String text = file.getText().getText();
        String[] text1 = text.split("\n");
        for (int i = 1; i < lineNum; i++) {
            index += text1[i - 1].length();
        }
        index += position;
        return index;
    }

    public static void cut(File file) {
        if (file.getText().getSelectedUntilThisPosition() == 0 && file.getText().getSelectedUntilThisLineNum() == 0) {
            printingString("nothing to cut");
            return;
        }
        cuttingThings(file, Math.max(getIndexx(file.getText().getSelectedUntilThisLineNum(),
                        file.getText().getSelectedUntilThisPosition(), file), file.getText().getCurserIndex()),
                Math.min(getIndexx(file.getText().getSelectedUntilThisLineNum(), file.getText().getSelectedUntilThisPosition(), file), file.getText().getCurserIndex()));
        printingString("cut successfully");
    }

    private static void cuttingThings(File file, int finalPosition, int currentPosition) {
        StringBuilder result = new StringBuilder();
        StringBuilder cut = new StringBuilder();
        for (int i = 0; i < currentPosition; i++) {
            result.append(file.getText().getText().charAt(i));
        }
        for (int i = finalPosition; i < file.getText().getText().length(); i++) {
            result.append(file.getText().getText().charAt(i));
        }
        for (int i = currentPosition; i <= finalPosition - 1; i++) {
            cut.append(file.getText().getText().charAt(i));
        }
        file.getText().setText(result.toString());
        file.getText().setCut(cut.toString());
    }


    public static void copy(File file) {
        if (file.getText().getSelectedUntilThisPosition() == 0 && file.getText().getSelectedUntilThisLineNum() == 0) {
            printingString("nothing to copy");
            return;
        }
        copyThings(file, Math.min(getIndexx(file.getText().getSelectedUntilThisLineNum(), file.getText().getSelectedUntilThisPosition(), file), file.getText().getCurserIndex()),
                Math.max(getIndexx(file.getText().getSelectedUntilThisLineNum(),
                                file.getText().getSelectedUntilThisPosition(), file),
                        file.getText().getCurserIndex()));

        printingString("copied successfully");
    }

    private static void copyThings(File file, int start, int end) {
        StringBuilder result = new StringBuilder();
        String text = file.getText().getText();
        for (int i = start; i < end; i++) {
            if (i <= text.length() - 1) {
                result.append(text.charAt(i));
            }
        }
        file.getText().setCopied(result.toString());

    }

    public static void showingDetails(File file) {
        ArrayList<String> usersWithAccess = findingUsersWithAccess(file);
        StringBuilder result = new StringBuilder();
        result.append("file name: " + file.getPath() + "\n");
        result.append("parent directory: " + file.getParent().getPath() + "\n");
        result.append("users with access:" + "\n");
        result.append("1. " + User.getLoggedInUser().getUsername() + "\n");
        int idx = 2;
        for (int i = 0; i < usersWithAccess.size(); i++) {
            result.append(idx + ". " + usersWithAccess.get(i) + "\n");
            idx++;
        }
        result.append("file content:" + "\n");
        if (!file.getFileFormat().equals("txt") && !file.getFileFormat().equals("java") && !file.getFileFormat().equals("c"))
            result.append("unable to show content" + "\n");
        else if (file.getText() != null) {
            if (file.getText().getText() != "") {
                result.append(file.getText().getText() + "\n");
            }

        }
        printingStringBuilder(result);
    }

    private static ArrayList<String> findingUsersWithAccess(File file) {
        ArrayList<String> result = new ArrayList<>();
        ArrayList<User> allusers = User.getUsers();
        for (int i = 0; i < allusers.size(); i++) {
            ArrayList<File> files = allusers.get(i).getWhatFilesIsSharedToMe();
            if (files.contains(file)) result.add(allusers.get(i).getUsername());
        }
        return result;
    }

    public static void writeThings(File file, Matcher matcher) {
        if (matcher.matches()) {
            String yourString = matcher.group("yourstring");
            if (yourString.length() > 80) {
                printingString("string is too big!");
                return;
            }
            writingThings(file, yourString);
            printingString("written successfully");
        }
    }

    private static void writingThings(File file, String yourString) {
        yourString = yourString.replaceAll("\\\\n", "\n");
        StringBuilder res = new StringBuilder();
        if (file.getText() != null) {
            int start = file.getText().getCurserIndex();
            for (int i = 0; i < start; i++) {
                if (file.getText() != null && file.getText().getText() != null && i <= file.getText().getText().length() - 1)
                    res.append(file.getText().getText().charAt(i));
            }
            res.append(yourString);
            if (file.getText() != null && file.getText().getText() != null) {
                for (int i = start; i < file.getText().getText().length(); i++) {
                    if (file.getText().getText().length() - 1 > i && i >= 0)
                        res.append(file.getText().getText().charAt(i));
                }
            }

            file.getText().setText(res.toString());
            file.getText().setCurserIndex(file.getText().getCurserIndex() + yourString.length());
        }
    }

    public static void paste(File file) {
        if (file.getText() != null && file.getText().getCut() == null && file.getText().getCopied() == null) {
            printingString("nothing to paste");
            return;
        }
        printingString("pasted successfully");
        if (file.getText().getCurserIndex() != getIndexx(file.getText().getSelectedUntilThisLineNum(), file.getText().getSelectedUntilThisPosition(), file))
            pastingThings(file);
    }

    private static void pastingThings(File file) {

        String text = file.getText().getText();
        int currentCurser = file.getText().getCurserIndex();
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < currentCurser; i++) {
            res.append(text.charAt(i));
        }

        res.append(file.getText().getCopied());
        if (text.contains("\n"))
            res.append("\n");
        for (int i = currentCurser; i < text.length(); i++) {
            res.append(text.charAt(i));
        }
        file.getText().setCurserIndex(file.getText().getCurserIndex() + file.getText().getCopied().length());
        file.getText().setText(res.toString());
        if (text.contains("\n")) file.getText().setCurserIndex(file.getText().getCurserIndex() + 1);
    }
}
