package Controller;

import Model.File;
import Model.User;
import Model.Directory;

import java.util.ArrayList;
import java.util.regex.Matcher;

import static View.Print.printingString;
import static View.Print.printingStringBuilder;

public class UserManu {
    public static void shareDir(Matcher matcher) {
        if (matcher.matches()) {
            String dirName = matcher.group("dirname");
            String userName = matcher.group("username");
            // dirName = extractDirName(dirName);

            if (!(Directory.getAllDirectories().contains(Directory.getDirByPath(matcher.group("dirname"))))) {
                printingString("no such file or directory");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(userName)))) {
                printingString("no such user exists");
                return;
            }
            if (User.getUsersByUsername(userName).getWhatDirIsSharedToMe().contains(Directory.getDirByPath(matcher.group("dirname")))) {
                System.out.println("already shared");
                return;
            }
            if (matcher.group("dirname").equals("root")) {
                System.out.println("you can't share root");
                return;
            }
            if (User.getUsersByUsername(userName).getWhoIBlocked().contains(User.getLoggedInUser())) {
                System.out.println("can't share, you are blocked");
                return;
            }
            if (User.getLoggedInUser().equals(User.getUsersByUsername(userName))) {
                printingString("You can't interact with yourself!");
                return;
            }
            System.out.println("shared successfully");
            User.getUsersByUsername(userName).addDirSharedToMe(Directory.getDirByPath(matcher.group("dirname")));
            Directory.getDirByPath(matcher.group("dirname")).setWhoShared(User.getLoggedInUser());
            Directory.getDirByPath(matcher.group("dirname")).setWhoIShareToIt(User.getUsersByUsername(userName));
            User.getLoggedInUser().addDirWhatIShareToOther(Directory.getDirByPath(matcher.group("dirname")));

        }
    }

    private static String extractDirName(String filePath) {
        String[] parts = filePath.split("/");
        if (parts.length >= 2) {
            return parts[parts.length - 1]; // Assuming the directory name is the second last part
        } else {
            return null; // Not enough parts to extract directory name

        }
    }

    private static boolean isShareListEmptyWithFlagUser(User user1, User user2) {
        boolean isempty = true;
        ArrayList<Directory> directories1 = user1.getWhatDirIsSharedToMe();
        for (int i = 0; i < directories1.size(); i++) {
            if (directories1.get(i).getWhoShared().equals(user2)) isempty = false;

        }
        ArrayList<File> files1 = user1.getWhatFilesIsSharedToMe();
        for (int y = 0; y < files1.size(); y++) {
            if (files1.get(y).getWhoShared().equals(user2)) isempty = false;

        }
        return isempty;
    }

    private static boolean isShareListEmpty(User user1, User user2) {
        boolean isempty = true;
        ArrayList<Directory> directories1 = user1.getWhatDirIsSharedToMe();
        for (int i = 0; i < directories1.size(); i++) {
            if (directories1.get(i).getWhoShared().equals(user2)) return false;

        }
        ArrayList<Directory> directories2 = user2.getWhatDirIsSharedToMe();
        for (int j = 0; j < directories2.size(); j++) {
            if (directories2.get(j).getWhoShared().equals(user1)) return false;

        }
        ArrayList<File> files1 = user1.getWhatFilesIsSharedToMe();
        for (int y = 0; y < files1.size(); y++) {
            if (files1.get(y).getWhoShared().equals(user2)) return false;

        }
        ArrayList<File> files2 = user2.getWhatFilesIsSharedToMe();
        for (int g = 0; g < files2.size(); g++) {
            if (files2.get(g).getWhoShared().equals(user1)) return false;
        }
        if (directories2.size() == 0 && files2.size() == 0)
            isempty = true;
        if (directories1.size() == 0 && files1.size() == 0)
            isempty = true;
        return isempty;
    }

    public static void viewSharedThings(Matcher matcher) {
        if (matcher.matches()) {
            int index = 1;
            String userName = matcher.group("username");
            if (User.getLoggedInUser().equals(User.getUsersByUsername(userName))) {
                printingString("You can't interact with yourself!");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(userName)))) {
                printingString("no such user exists");
                return;
            }
            if (isShareListEmpty(User.getLoggedInUser(), User.getUsersByUsername(userName))) {
                printingString("share list empty");
                return;
            }
            StringBuilder result = new StringBuilder();
            result.append("shared to " + userName + " by me:" + "\n");
            result.append("dir:" + "\n");
            ArrayList<Directory> directories = User.getUsersByUsername(userName).getWhatDirIsSharedToMe();
            for (int i = 0; i < directories.size(); i++) {
                if (directories.get(i).getWhoShared().equals(User.getLoggedInUser())) {
                    result.append(index + ". " + directories.get(i).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("file:" + "\n");
            ArrayList<File> files = User.getUsersByUsername(userName).getWhatFilesIsSharedToMe();
            for (int j = 0; j < files.size(); j++) {
                if (files.get(j).getWhoShared().equals(User.getLoggedInUser()) && files.get(j).getIsZip() == false) {
                    result.append(index + ". " + files.get(j).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("zip:" + "\n");
            for (int h = 0; h < files.size(); h++) {
                if (files.get(h).getWhoShared().equals(User.getLoggedInUser()) && files.get(h).getIsZip() == true) {
                    result.append(index + ". " + files.get(h).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("shared to me by " + userName + ":" + "\n");
            result.append("dir:" + "\n");
            ArrayList<Directory> directories1 = User.getLoggedInUser().getWhatDirIsSharedToMe();
            for (int n = 0; n < directories1.size(); n++) {
                if (directories1.get(n).getWhoShared().getUsername().equals(User.getUsersByUsername(userName).getUsername())) {
                    result.append(index + ". " + directories1.get(n).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("file:" + "\n");
            ArrayList<File> files1 = User.getLoggedInUser().getWhatFilesIsSharedToMe();
            for (int j = 0; j < files1.size(); j++) {
                if (files1.get(j).getWhoShared().equals(User.getUsersByUsername(userName)) && files1.get(j).getIsZip() == false) {
                    result.append(index + ". " + files1.get(j).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("zip:" + "\n");
            for (int h = 0; h < files1.size(); h++) {
                if (files1.get(h).getWhoShared().equals(User.getUsersByUsername(userName)) && files1.get(h).getIsZip() == true && files1.get(h).getFileName().equals("zip")) {
                    result.append(index + ". " + files1.get(h).getPath() + "\n");
                    index++;
                }

            }
            printingStringBuilder(result);
        }
    }

    private static boolean isShareListEmptyForFlagMe(User user1, User user2) {
        boolean isempty = true;
        ArrayList<Directory> directories2 = user2.getWhatDirIsSharedToMe();
        for (int j = 0; j < directories2.size(); j++) {
            if (directories2.get(j).getWhoShared().equals(user1)) isempty = false;

        }
        ArrayList<File> files2 = user2.getWhatFilesIsSharedToMe();
        for (int g = 0; g < files2.size(); g++) {
            if (files2.get(g).getWhoShared().equals(user1)) isempty = false;
        }
        if (directories2.size() == 0 && files2.size() == 0)
            isempty = true;
        return isempty;
    }

    public static void viewWithFlagMe(Matcher matcher) {
        if (matcher.matches()) {
            int index = 1;
            String userName = matcher.group("username");

            if (User.getLoggedInUser().equals(User.getUsersByUsername(userName))) {
                printingString("You can't interact with yourself!");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(userName)))) {
                printingString("no such user exists");
                return;
            }
            if (isShareListEmptyForFlagMe(User.getLoggedInUser(), User.getUsersByUsername(userName))) {
                printingString("share list empty");
                return;
            }


            StringBuilder result = new StringBuilder();
            result.append("shared to " + userName + " by me:" + "\n");
            result.append("dir:" + "\n");
            ArrayList<Directory> directories = User.getUsersByUsername(userName).getWhatDirIsSharedToMe();
            for (int i = 0; i < directories.size(); i++) {
                if (directories.get(i).getWhoShared().getUsername().equals(User.getLoggedInUser().getUsername())) {
                    result.append(index + ". " + directories.get(i).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("file:" + "\n");
            ArrayList<File> files = User.getUsersByUsername(userName).getWhatFilesIsSharedToMe();
            for (int j = 0; j < files.size(); j++) {
                if (files.get(j).getWhoShared().equals(User.getLoggedInUser()) && files.get(j).getIsZip() == false) {
                    result.append(index + ". " + files.get(j).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("zip:" + "\n");
            for (int h = 0; h < files.size(); h++) {
                if (files.get(h).getWhoShared().equals(User.getLoggedInUser()) && files.get(h).getIsZip() == true && files.get(h).getFileName().equals("zip")) {
                    result.append(index + ". " + files.get(h).getPath() + "\n");
                    index++;
                }
            }
            printingStringBuilder(result);
        }
    }

    public static void viewWithFlagUser(Matcher matcher) {
        if (matcher.matches()) {
            int index = 1;
            String userName = matcher.group("username");
            if (User.getLoggedInUser().equals(User.getUsersByUsername(userName))) {
                printingString("You can't interact with yourself!");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(userName)))) {
                printingString("no such user exists");
                return;
            }
            if (isShareListEmptyWithFlagUser(User.getLoggedInUser(), User.getUsersByUsername(userName))) {
                printingString("share list empty");
                return;
            }
            StringBuilder result = new StringBuilder();
            result.append("shared to me by " + userName + ":" + "\n");
            result.append("dir:" + "\n");
            ArrayList<Directory> directories1 = User.getLoggedInUser().getWhatDirIsSharedToMe();
            for (int i = 0; i < directories1.size(); i++) {
                if (directories1.get(i).getWhoShared().getUsername().equals(User.getUsersByUsername(userName).getUsername())) {
                    result.append(index + ". " + directories1.get(i).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("file:" + "\n");
            ArrayList<File> files1 = User.getLoggedInUser().getWhatFilesIsSharedToMe();
            for (int j = 0; j < files1.size(); j++) {
                if (files1.get(j).getWhoShared().equals(User.getUsersByUsername(userName)) && files1.get(j).getIsZip() == false) {
                    result.append(index + ". " + files1.get(j).getPath() + "\n");
                    index++;
                }
            }
            index = 1;
            result.append("zip:" + "\n");
            for (int h = 0; h < files1.size(); h++) {
                if (files1.get(h).getWhoShared().equals(User.getUsersByUsername(userName)) && files1.get(h).getIsZip() == true && files1.get(h).getFileName().equals("zip")) {
                    result.append(index + ". " + files1.get(h).getPath() + "\n");
                    index++;
                }

            }
            index = 1;
            printingStringBuilder(result);
        }
    }

    private static boolean isThisSharedByLoggedInUSer(Directory directory, User user) {
        ArrayList<Directory> directories = user.getWhatDirIsSharedToMe();
        for (int i = 0; i < directories.size(); i++) {
            if (directories.get(i).getWhoShared().getUsername().equals(User.getLoggedInUser().getUsername()) && directories.get(i).equals(directory))
                return true;
        }
        return false;
    }

    private static boolean isAnyUserAvailableForDir(Directory directory) {
        boolean available = false;
        ArrayList<User> users = User.getUsers();
        for (int i = 0; i < users.size(); i++) {
            if (!(users.get(i).getWhoIBlocked().contains(User.getLoggedInUser())) && !isThisSharedByLoggedInUSer(directory, users.get(i)) && !User.getLoggedInUser().equals(users.get(i))) {
                available = true;
            }
        }
        return available;
    }

    public static void shareDirWithAll(Matcher matcher) {
        if (matcher.matches()) {
            String dirname = matcher.group("dirname");
            if (!Directory.getAllDirectories().contains(Directory.getDirByPath(matcher.group("dirname")))) {
                printingString("no such file or directory");
                return;
            }
            if (matcher.group("dirname").equals("root")) {
                printingString("you can't share root");
                return;
            }
            if (!isAnyUserAvailableForDir(User.getLoggedInUser().getDirByPath(matcher.group("dirname")))) {
                printingString("no available user");
                return;
            }

            printingString("shared successfully");
            ArrayList<User> users = User.getUsers();
            for (int f = 0; f < users.size(); f++) {
                if (!isThisSharedByLoggedInUSer(User.getLoggedInUser().getDirByPath(dirname), users.get(f))) {
                    User.getUsersByUsername(users.get(f).getUsername()).addDirSharedToMe(User.getLoggedInUser().getDirByPath(matcher.group("dirname")));
                    User.getLoggedInUser().getDirByPath(matcher.group("dirname")).setWhoShared(User.getLoggedInUser());
                    User.getLoggedInUser().getDirByPath(matcher.group("dirname")).setWhoIShareToIt(User.getUsersByUsername(users.get(f).getUsername()));
                    User.getLoggedInUser().addDirWhatIShareToOther(User.getLoggedInUser().getDirByPath(matcher.group("dirname")));
                }

            }
        }
    }

    private static boolean isAnyUserAvailableForFile(File file) {
        boolean available = false;
        ArrayList<User> users = User.getUsers();
        for (int i = 0; i < users.size(); i++) {
            if (!(users.get(i).getWhoIBlocked().contains(User.getLoggedInUser())) &&
                    !(users.get(i).getWhatFilesIsSharedToMe().contains(file)) &&
                    !User.getLoggedInUser().equals(users.get(i))) {
                available = true;
            }
        }
        return available;
    }

    public static void shareFileWithAll(Matcher matcher) {
        if (matcher.matches()) {
            String filename = matcher.group("filename");
            if (!User.getLoggedInUser().getWhatFileIHavesIHave().contains(File.getFileByPath(filename))) {
                printingString("no such file or directory");
                return;
            }
            if (!isAnyUserAvailableForFile(File.getFileByPath(filename))) {
                printingString("no available user");
                return;
            }
            printingString("shared successfully");
            ArrayList<User> users = User.getUsers();
            for (int f = 0; f < users.size(); f++) {
                if (!(User.getLoggedInUser().getWhoIBlocked().contains(users.get(f))) &&
                        !(User.getUsersByUsername(users.get(f).getUsername())).getWhoIBlocked().contains(User.getLoggedInUser()) &&
                        !User.getUsersByUsername(users.get(f).getUsername()).getWhatFilesIsSharedToMe().contains(File.getFileByPath(filename)) &&
                        !users.get(f).equals(User.getLoggedInUser())) {
                    User.getUsersByUsername(users.get(f).getUsername()).addFileSharedToMe(File.getFileByPath(filename));
                    File.getFileByPath(filename).setWhoShared(User.getLoggedInUser());
                    File.getFileByPath(filename).setWhoISharedToIt(User.getUsersByUsername(users.get(f).getUsername()));
                    User.getLoggedInUser().addFileWhatIShareToOther(File.getFileByPath(filename));
                }
            }
        }
    }

    public static void blockUser(Matcher matcher) {
        if (matcher.matches()) {
            String userName = matcher.group("username");
            if (User.getLoggedInUser().equals(User.getUsersByUsername(userName))) {
                printingString("You can't interact with yourself!");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(userName)))) {
                printingString("no such user exists");
                return;
            }
            if (User.getLoggedInUser().getWhoIBlocked().contains(User.getUsersByUsername(userName))) {
                printingString("user already blocked");
                return;
            }
            printingString("user " + userName + " is now blocked");
            User.getLoggedInUser().setWhoIBlocked(User.getUsersByUsername(userName));
            User.getUsersByUsername(userName).setWhoBlockedMe(User.getLoggedInUser());
        }
    }

    public static void unblockUser(Matcher matcher) {
        if (matcher.matches()) {
            String username = matcher.group("username");
            if (User.getLoggedInUser().equals(User.getUsersByUsername(username))) {
                printingString("You can't interact with yourself!");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(username)))) {
                printingString("no such user exists");
                return;
            }
            if (!User.getLoggedInUser().getWhoIBlocked().contains(User.getUsersByUsername(username))) {
                printingString("user is not blocked");
                return;
            }
            printingString("user " + username + " is now unblocked");
            User.getLoggedInUser().removeWhoIBlocked(User.getUsersByUsername(username));
            User.getUsersByUsername(username).removeWhoBlockedMe(User.getLoggedInUser());
        }
    }

    public static void showingBlockList() {
        int idx = 1;
        ArrayList<User> whoIBlocked = User.getLoggedInUser().getWhoIBlocked();
        ArrayList<User> whoBlockedMe = User.getLoggedInUser().getWhoBlockedMe();
        if (whoIBlocked.isEmpty() && whoBlockedMe.isEmpty()) {
            System.out.println("block list empty");
        } else {
            StringBuilder result = new StringBuilder();
            result.append("blocked:" + "\n");
            for (int a = 0; a < whoIBlocked.size(); a++) {
                result.append(idx + ". " + whoIBlocked.get(a).getUsername() + "\n");
                idx++;
            }
            idx = 1;
            result.append("blocker:" + "\n");
            for (int t = 0; t < whoBlockedMe.size(); t++) {
                result.append(idx + ". " + whoBlockedMe.get(t).getUsername() + "\n");
                idx++;
            }
            printingStringBuilder(result);
        }
    }

    public static void logout() {
        if (User.getLoggedInUser() != null) {
            printingString("logged out successfully");
            if (User.getLoggedInUser().getIsOneTime()) {
                printingString("account removed!");
                User.removeFromUsersForOneTime(User.getLoggedInUser());
            }
        }
    }

    public static void shareFile(Matcher matcher) {
        if (matcher.matches()) {
            String fileName = matcher.group("filename");
            String userName = matcher.group("username");


            if (!File.getAllFiles().contains(File.getFileByPath(fileName))) {
                System.out.println("no such file or directory");
                return;
            }
            if (User.getLoggedInUser().equals(User.getUsersByUsername(userName))) {
                System.out.println("You can't interact with yourself!");
                return;
            }
            if (!(User.getUsers().contains(User.getUsersByUsername(userName)))) {
                System.out.println("no such user exists");
                return;
            }
            if (User.getUsersByUsername(userName) != null) {
                if (User.getUsersByUsername(userName).getWhatFilesIsSharedToMe().contains(File.getFileByPath(fileName))) {
                    System.out.println("already shared");
                    return;
                }
                if (User.getUsersByUsername(userName).getWhoIBlocked().contains(User.getLoggedInUser())) {
                    System.out.println("can't share, you are blocked");
                    return;
                }

                System.out.println("shared successfully");
                if (File.getFileByPath(fileName) != null) {
                    User.getUsersByUsername(userName).addFileSharedToMe(File.getFileByPath(fileName));
                    File.getFileByPath(fileName).setWhoShared(User.getLoggedInUser());
                    File.getFileByPath(fileName).setWhoISharedToIt(User.getUsersByUsername(userName));
                    User.getLoggedInUser().addFileWhatIShareToOther(File.getFileByPath(fileName));
                }
            }
        }
    }
}